
import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysisResult, EventType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const parseEventNote = async (note: string): Promise<AIAnalysisResult> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Parse the following messy event booking note for CineParty. 
    Current year is ${new Date().getFullYear()}. 
    Extract key information. Pay special attention to entry effects: Fog Entry, Bubble Entry, Name Plate, Fog + Bubble, or Rose Entry.
    Note: "${note}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          date: { type: Type.STRING, description: "ISO date format YYYY-MM-DD" },
          type: { type: Type.STRING, enum: Object.values(EventType) },
          clientName: { type: Type.STRING },
          startTime: { type: Type.STRING, description: "Time in HH:mm format" },
          guestCount: { type: Type.NUMBER },
          extras: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING, enum: ['Fog Entry', 'Bubble Entry', 'Name Plate', 'Fog + Bubble', 'Rose Entry'] } 
          },
          confidence: { type: Type.NUMBER, description: "Scale 0-1" },
          explanation: { type: Type.STRING }
        },
        required: ["confidence", "explanation"]
      }
    }
  });

  return JSON.parse(response.text) as AIAnalysisResult;
};

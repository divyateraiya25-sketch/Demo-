
export enum EventType {
  BIRTHDAY = 'Birthday',
  CINEMA_NIGHT = 'Cinema Night',
  ANNIVERSARY = 'Anniversary',
  CORPORATE = 'Corporate',
  PROPOSAL = 'Proposal',
  KIDS_PARTY = 'Kids Party'
}

export enum BookingStatus {
  PENDING = 'Pending',
  CONFIRMED = 'Confirmed',
  COMPLETED = 'Completed',
  CANCELLED = 'Cancelled'
}

export type ExtraService = 'Fog Entry' | 'Bubble Entry' | 'Name Plate' | 'Fog + Bubble' | 'Rose Entry';

export interface Booking {
  id: string;
  clientName: string;
  date: string; // ISO format YYYY-MM-DD
  startTime: string; // HH:mm
  type: EventType;
  status: BookingStatus;
  notes: string;
  guestCount: number;
  totalPrice: number;
  extras: ExtraService[];
}

export interface AIAnalysisResult {
  date?: string;
  type?: EventType;
  clientName?: string;
  startTime?: string;
  guestCount?: number;
  extras?: ExtraService[];
  confidence: number;
  explanation: string;
}

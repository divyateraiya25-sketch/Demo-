
import React, { useState, useEffect } from 'react';
import { parseEventNote } from '../services/geminiService';
import { Booking, BookingStatus, EventType, ExtraService } from '../types';
// Customizing icons for bigger impact
import { Sparkles, Loader2, Save, Trash2, Users, Wand2, Wind, Droplets, CreditCard, Layers, IndianRupee, Clock, AlertCircle, Film, Star, Heart } from 'lucide-react';

interface SmartBookingFormProps {
  onAdd: (booking: Booking) => void;
}

const SmartBookingForm: React.FC<SmartBookingFormProps> = ({ onAdd }) => {
  const [messyNote, setMessyNote] = useState('');
  const [isParsing, setIsParsing] = useState(false);
  const [isManualPrice, setIsManualPrice] = useState(false);
  const [formData, setFormData] = useState<Partial<Booking>>({
    status: BookingStatus.PENDING,
    totalPrice: 2000,
    guestCount: 0,
    extras: []
  });

  const MAX_GUESTS = 25;

  const toggleExtra = (extra: ExtraService) => {
    setFormData(prev => {
      const current = prev.extras || [];
      if (current.includes(extra)) return { ...prev, extras: current.filter(e => e !== extra) };
      return { ...prev, extras: [...current, extra] };
    });
  };

  const handleAISmartExtract = async () => {
    if (!messyNote.trim()) return;
    setIsParsing(true);
    try {
      const result = await parseEventNote(messyNote);
      const validatedGuests = Math.min(result.guestCount || 0, MAX_GUESTS);
      setFormData(prev => ({
        ...prev,
        clientName: result.clientName || prev.clientName,
        date: result.date || prev.date,
        startTime: result.startTime || prev.startTime,
        type: result.type || prev.type,
        guestCount: validatedGuests,
        extras: result.extras || prev.extras
      }));
      setIsManualPrice(false);
    } catch (error) {
      console.error("AI Parse failed", error);
    } finally {
      setIsParsing(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.clientName || !formData.date || !formData.type) return;
    
    const newBooking: Booking = {
      id: Math.random().toString(36).substr(2, 9),
      clientName: formData.clientName as string,
      date: formData.date as string,
      startTime: formData.startTime || '18:00',
      type: formData.type as EventType,
      status: formData.status as BookingStatus,
      notes: messyNote,
      guestCount: Math.min(Number(formData.guestCount) || 0, MAX_GUESTS),
      totalPrice: Number(formData.totalPrice) || 2000,
      extras: formData.extras || []
    };
    onAdd(newBooking);
    setFormData({ status: BookingStatus.PENDING, totalPrice: 2000, guestCount: 0, extras: [] });
    setMessyNote('');
    setIsManualPrice(false);
  };

  // Enhanced color and visual mapping for the big entry modules
  const extraDetails: Record<ExtraService, { 
    icon: any; 
    vibe: string; 
    gradient: string; 
    shadow: string;
    iconColor: string;
    description: string;
  }> = {
    'Fog Entry': { 
      icon: Wind, 
      vibe: 'Mystical', 
      gradient: 'from-blue-600 to-indigo-700', 
      shadow: 'shadow-blue-500/40',
      iconColor: 'text-blue-100',
      description: 'Cinematic clouds for a grand walk-in.'
    },
    'Bubble Entry': { 
      icon: Droplets, 
      vibe: 'Dreamy', 
      gradient: 'from-cyan-400 to-blue-500', 
      shadow: 'shadow-cyan-400/40',
      iconColor: 'text-cyan-50',
      description: 'Magical floating spheres of joy.'
    },
    'Name Plate': { 
      icon: CreditCard, 
      vibe: 'VIP Status', 
      gradient: 'from-amber-400 to-orange-600', 
      shadow: 'shadow-amber-500/40',
      iconColor: 'text-amber-50',
      description: 'Your name in the spotlight.'
    },
    'Fog + Bubble': { 
      icon: Layers, 
      vibe: 'Ultimate', 
      gradient: 'from-purple-600 to-fuchsia-700', 
      shadow: 'shadow-purple-500/40',
      iconColor: 'text-purple-100',
      description: 'The complete atmospheric experience.'
    },
    'Rose Entry': { 
      icon: Flower2, 
      vibe: 'Romantic', 
      gradient: 'from-rose-500 to-red-700', 
      shadow: 'shadow-rose-500/40',
      iconColor: 'text-rose-100',
      description: 'Classic petal drop for special moments.'
    },
  };

  return (
    <div className="space-y-12 max-w-7xl mx-auto pb-24 animate-slideUp">
      <div className="bg-white border border-slate-200 rounded-[4rem] p-10 lg:p-20 shadow-2xl relative overflow-hidden">
        
        {/* Animated Background Polish */}
        <div className="absolute top-0 right-0 w-96 h-96 gold-shimmer opacity-5 blur-[100px] rounded-full -mr-40 -mt-40"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/5 blur-[100px] rounded-full -ml-40 -mb-40"></div>

        <div className="mb-16 text-center relative z-10">
          <div className="inline-flex items-center gap-3 px-6 py-2.5 rounded-full bg-slate-900 text-white text-[11px] font-black uppercase tracking-[0.4em] mb-6">
            <Film className="w-4 h-4 text-amber-500" /> Casting Call
          </div>
          <h2 className="text-5xl lg:text-6xl font-black text-slate-900 uppercase tracking-tighter">Design Your Premiere</h2>
          <p className="text-slate-500 font-bold text-lg tracking-wide mt-4">Every detail matters in a CineParty production.</p>
        </div>

        {/* AI Intake Console */}
        <div className="mb-20 relative z-10 group">
          <div className="flex flex-col lg:flex-row gap-8">
            <div className="flex-1 relative">
              <div className="absolute -top-3 left-10 px-4 bg-white text-[10px] font-black uppercase text-amber-600 tracking-[0.3em] z-20">AI Smart Inbox</div>
              <textarea
                className="w-full bg-slate-50 border-2 border-slate-100 rounded-[3rem] p-10 text-slate-900 focus:ring-0 focus:border-slate-900 outline-none transition-all placeholder:text-slate-300 font-bold text-xl resize-none min-h-[180px] shadow-inner"
                placeholder="Ex: 'Mehul wants a Proposal event on 14th Feb, 7pm. 2 guests. He wants Rose Entry + Fog Entry.'"
                value={messyNote}
                onChange={(e) => setMessyNote(e.target.value)}
              />
            </div>
            <button
              type="button"
              onClick={handleAISmartExtract}
              disabled={isParsing || !messyNote}
              className="bg-slate-900 hover:scale-[1.02] active:scale-95 px-14 rounded-[3rem] text-white flex flex-col items-center justify-center gap-4 disabled:opacity-30 transition-all shadow-2xl shadow-slate-900/20 min-w-[240px]"
            >
              {isParsing ? <Loader2 className="w-12 h-12 animate-spin text-amber-500" /> : <Wand2 className="w-12 h-12 text-amber-500" />}
              <span className="text-[11px] font-black uppercase tracking-[0.3em]">Extract Details</span>
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-16 relative z-10">
          <div className="lg:col-span-8 space-y-16">
            {/* Primary Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-4">
                <label className="text-[11px] font-extrabold uppercase text-slate-400 tracking-widest ml-4">Lead Talent (Name)</label>
                <input
                  type="text" required
                  className="w-full bg-white border-2 border-slate-100 rounded-3xl p-7 text-slate-900 font-black text-xl focus:border-slate-900 outline-none transition-all shadow-sm"
                  value={formData.clientName || ''}
                  onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                />
              </div>
              <div className="space-y-4">
                <label className="text-[11px] font-extrabold uppercase text-slate-400 tracking-widest ml-4">Production Genre</label>
                <select
                  required
                  className="w-full bg-white border-2 border-slate-100 rounded-3xl p-7 text-slate-900 font-black text-xl focus:border-slate-900 outline-none transition-all shadow-sm appearance-none"
                  value={formData.type || ''}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as EventType })}
                >
                  <option value="">Select Genre...</option>
                  {Object.values(EventType).map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-4">
                <label className="text-[11px] font-extrabold uppercase text-slate-400 tracking-widest ml-4">Premiere Date</label>
                <input
                  type="date" required
                  className="w-full bg-white border-2 border-slate-100 rounded-3xl p-7 text-slate-900 font-black text-xl focus:border-slate-900 outline-none transition-all shadow-sm"
                  value={formData.date || ''}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                />
              </div>
              <div className="space-y-4">
                <label className="text-[11px] font-extrabold uppercase text-slate-400 tracking-widest ml-4">Slot Start Time</label>
                <input
                  type="time"
                  className="w-full bg-white border-2 border-slate-100 rounded-3xl p-7 text-slate-900 font-black text-xl focus:border-slate-900 outline-none transition-all shadow-sm"
                  value={formData.startTime || ''}
                  onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                />
              </div>
            </div>

            {/* Entry Upgrade Section - The Colorful & Big Customization */}
            <div className="space-y-10">
              <div className="flex items-center justify-between ml-4">
                 <label className="text-[12px] font-black uppercase text-slate-900 tracking-widest">Entry SFX Modules</label>
                 <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Multiple Selection Allowed</span>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                {(Object.keys(extraDetails) as ExtraService[]).map((extra) => {
                  const { icon: Icon, vibe, gradient, shadow, iconColor, description } = extraDetails[extra];
                  const active = formData.extras?.includes(extra);
                  return (
                    <button
                      key={extra} type="button" onClick={() => toggleExtra(extra)}
                      className={`relative group flex items-center gap-6 p-8 rounded-[3rem] border-2 transition-all duration-500 text-left ${
                        active 
                          ? `bg-gradient-to-br ${gradient} border-transparent text-white ${shadow} scale-[1.03]` 
                          : 'bg-white border-slate-100 hover:border-slate-300 text-slate-500 hover:shadow-xl'
                      }`}
                    >
                      {active && (
                        <div className="absolute top-6 right-8 animate-bounce">
                           <Star className="w-6 h-6 fill-white text-white" />
                        </div>
                      )}
                      
                      <div className={`p-6 rounded-[2.5rem] transition-all duration-500 group-hover:scale-110 ${
                        active ? 'bg-white/20' : 'bg-slate-50 text-slate-300'
                      }`}>
                        <Icon className={`w-14 h-14 ${active ? iconColor : ''}`} />
                      </div>
                      
                      <div className="flex-1 space-y-1">
                        <p className={`text-[10px] font-black uppercase tracking-[0.2em] opacity-60`}>{vibe}</p>
                        <h4 className={`text-2xl font-black uppercase tracking-tight`}>{extra}</h4>
                        <p className={`text-[11px] font-bold leading-tight opacity-70 ${active ? 'text-white' : 'text-slate-400'}`}>
                          {description}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Pricing & Summary Sidebar */}
          <div className="lg:col-span-4 space-y-10">
            <div className="bg-slate-50 border border-slate-200 rounded-[4rem] p-12 space-y-12 sticky top-10">
              
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-extrabold uppercase text-slate-400 tracking-widest ml-4">Guest List</span>
                  <div className="px-4 py-1 bg-slate-900 text-white rounded-full text-[10px] font-black uppercase">Max 25</div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="flex-1 relative">
                    <input
                      type="number"
                      max={MAX_GUESTS}
                      className="w-full bg-white border-2 border-slate-100 rounded-[2.5rem] p-8 text-5xl font-black text-center text-slate-900 outline-none focus:border-slate-900 transition-all shadow-sm"
                      value={formData.guestCount || 0}
                      onChange={(e) => setFormData({ ...formData, guestCount: Math.min(Number(e.target.value), 25) })}
                    />
                  </div>
                  <Users className="w-12 h-12 text-slate-200" />
                </div>
              </div>

              <div className="pt-12 border-t border-slate-200 space-y-8">
                 <div className="flex items-center justify-between">
                  <span className="text-[11px] font-extrabold uppercase text-slate-400 tracking-widest ml-4">Total Quote</span>
                </div>
                <div className="relative">
                  <span className="absolute left-8 top-1/2 -translate-y-1/2 text-slate-300 text-4xl font-cinema">₹</span>
                  <input
                    type="number"
                    className="w-full bg-white border-2 border-slate-100 rounded-[3rem] p-12 pl-16 text-6xl font-black text-center text-slate-900 outline-none focus:border-slate-900 transition-all shadow-sm"
                    value={formData.totalPrice || 2000}
                    onChange={(e) => { setFormData({ ...formData, totalPrice: Number(e.target.value) }); setIsManualPrice(true); }}
                  />
                </div>
                
                <div className="bg-emerald-50 border border-emerald-100 p-8 rounded-[2.5rem] flex items-center gap-6">
                   <div className="w-14 h-14 bg-emerald-500 rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-emerald-500/20">
                      <Clock className="w-7 h-7 text-white" />
                   </div>
                   <p className="text-[12px] text-emerald-900 font-extrabold uppercase leading-tight">
                     ₹1,000 Advance required to lock the slot.
                   </p>
                </div>
              </div>

              <div className="pt-8 flex flex-col gap-6">
                <button
                  type="submit"
                  className="w-full bg-slate-900 hover:scale-[1.02] active:scale-95 text-white py-10 rounded-[3rem] font-black text-3xl transition-all flex items-center justify-center gap-5 shadow-2xl shadow-slate-900/40"
                >
                  <Save className="w-10 h-10 text-amber-500" /> CONFIRM BOOKING
                </button>
                <button
                  type="button"
                  onClick={() => { setFormData({ status: BookingStatus.PENDING, totalPrice: 2000, guestCount: 0, extras: [] }); setMessyNote(''); }}
                  className="w-full py-6 bg-white border-2 border-slate-100 rounded-[2.5rem] text-slate-300 font-black uppercase text-xs tracking-widest hover:text-red-500 hover:border-red-100 transition-all"
                >
                  Reset Form
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

// Custom Flower Icon for Rose Entry
const Flower2 = (props: any) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2v10"/><path d="M12 12c-2.5-3.5-6-3.5-8-2 2-3 5.5-3 8 2z"/><path d="M12 12c2.5-3.5 6-3.5 8-2-2-3-5.5-3-8 2z"/><path d="M12 12c-3.5 2.5-3.5 6-2 8 3-2 3-5.5-2-8z"/><path d="M12 12c3.5 2.5 3.5 6 2 8-3-2-3-5.5 2-8z"/><circle cx="12" cy="12" r="2"/></svg>
);

export default SmartBookingForm;

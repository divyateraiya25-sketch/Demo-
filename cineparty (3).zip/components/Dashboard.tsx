
import React from 'react';
import { Booking, BookingStatus, EventType } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell as ReCell, AreaChart, Area
} from 'recharts';
import { Calendar, Users, IndianRupee, Film, Zap, MapPin, Phone, ExternalLink, Activity, Star, Clock, AlertCircle, TrendingUp, Sparkles, MessageSquare } from 'lucide-react';

interface DashboardProps {
  bookings: Booking[];
}

const COLORS = ['#d4af37', '#0f172a', '#3b82f6', '#ec4899', '#8b5cf6', '#10b981'];

const Dashboard: React.FC<DashboardProps> = ({ bookings }) => {
  const stats = {
    total: bookings.length,
    confirmed: bookings.filter(b => b.status === BookingStatus.CONFIRMED).length,
    revenue: bookings.reduce((acc, curr) => acc + curr.totalPrice, 0),
    guests: bookings.reduce((acc, curr) => acc + curr.guestCount, 0),
  };

  const typeData = Object.values(EventType).map(type => ({
    name: type,
    value: bookings.filter(b => b.type === type).length
  })).filter(d => d.value > 0);

  const upcomingSlots = bookings.filter(b => {
    const eventDate = new Date(`${b.date}T${b.startTime}`);
    const now = new Date();
    const diff = eventDate.getTime() - now.getTime();
    return diff > 0 && diff < (24 * 60 * 60 * 1000) && b.status === BookingStatus.CONFIRMED;
  }).sort((a,b) => new Date(`${a.date}T${a.startTime}`).getTime() - new Date(`${b.date}T${b.startTime}`).getTime());

  const recentActivity = [
    { name: "Rahul S.", action: "Booked Fog Entry", time: "2 mins ago", icon: Zap },
    { name: "Sanya K.", action: "Confirmed Birthday", time: "1 hour ago", icon: Star },
    { name: "Amit P.", action: "Added Rose Entry", time: "3 hours ago", icon: Sparkles },
  ];

  return (
    <div className="space-y-10 pb-20">
      
      {/* Premium Hero Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Studio Bookings', value: stats.total, icon: Film, color: 'text-slate-900', bg: 'bg-white' },
          { label: 'Confirmed Acts', value: stats.confirmed, icon: CheckCircle, color: 'text-blue-600', bg: 'bg-white' },
          { label: 'Net Revenue', value: `₹${stats.revenue.toLocaleString()}`, icon: IndianRupee, color: 'text-slate-900', bg: 'bg-white' },
          { label: 'Total Audience', value: stats.guests, icon: Users, color: 'text-slate-900', bg: 'bg-white' },
        ].map((item, i) => (
          <div key={i} className="bg-white border border-slate-100 p-8 rounded-[2.5rem] shadow-[0_10px_30px_rgba(0,0,0,0.03)] hover:shadow-[0_20px_50px_rgba(0,0,0,0.06)] transition-all group overflow-hidden relative">
            <div className="absolute top-0 right-0 w-24 h-24 bg-slate-50 rounded-bl-[4rem] -mr-8 -mt-8 group-hover:bg-slate-100 transition-colors"></div>
            <p className="text-slate-400 text-[11px] font-extrabold uppercase tracking-[0.2em] mb-2">{item.label}</p>
            <div className="flex items-center gap-4">
              <h3 className="text-4xl font-black text-slate-900 tracking-tighter">{item.value}</h3>
              {i === 2 && <TrendingUp className="w-5 h-5 text-emerald-500" />}
            </div>
            <div className="mt-8 flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-300 uppercase">Quarterly Growth</span>
              <div className="flex -space-x-2">
                 {[1,2,3].map(j => <div key={j} className="w-6 h-6 rounded-full border-2 border-white bg-slate-100"></div>)}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left Col: Reminders & Performance */}
        <div className="lg:col-span-8 space-y-10">
          
          {/* Upcoming Slots - Now with Gold Accents */}
          <div className="bg-slate-900 rounded-[3rem] p-10 relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 w-1/2 h-full gold-shimmer opacity-5"></div>
            <div className="flex items-center justify-between mb-8 relative z-10">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center">
                  <Clock className="text-slate-900 w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white uppercase tracking-tight">Today's Premiere Roll</h3>
                  <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest">Active Schedule</p>
                </div>
              </div>
              <div className="px-5 py-2 rounded-full border border-slate-700 text-white text-[10px] font-black uppercase">
                {upcomingSlots.length} Slots Today
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
              {upcomingSlots.length > 0 ? upcomingSlots.map(slot => (
                <div key={slot.id} className="bg-white/5 border border-white/10 rounded-[2rem] p-6 hover:bg-white/10 transition-all flex items-center gap-6 group">
                   <div className="text-center">
                      <p className="text-[32px] font-cinema text-white leading-none">{slot.startTime}</p>
                      <p className="text-[10px] font-black text-slate-500 uppercase">On Air</p>
                   </div>
                   <div className="flex-1 border-l border-white/10 pl-6">
                      <p className="text-white font-black text-lg">{slot.clientName}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-pink-500 text-[10px] font-black uppercase tracking-widest">{slot.type}</span>
                        <div className="w-1 h-1 rounded-full bg-slate-600"></div>
                        <span className="text-slate-400 text-[10px] font-bold">{slot.guestCount} Guests</span>
                      </div>
                   </div>
                </div>
              )) : (
                <div className="col-span-2 py-10 text-center border-2 border-dashed border-slate-800 rounded-[2rem]">
                   <p className="text-slate-600 font-bold uppercase tracking-widest text-xs">No active slots scheduled for next 24h</p>
                </div>
              )}
            </div>
          </div>

          <div className="bg-white border border-slate-100 rounded-[3rem] p-10 shadow-sm">
             <div className="flex items-center justify-between mb-10">
                <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-3">
                  <Activity className="text-blue-500 w-5 h-5" /> Revenue Projection
                </h3>
                <div className="flex gap-4">
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase text-slate-400"><div className="w-2 h-2 rounded-full bg-blue-500"></div> Bookings</div>
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase text-slate-400"><div className="w-2 h-2 rounded-full bg-slate-100"></div> Potential</div>
                </div>
             </div>
             <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={bookings.slice(0, 7)}>
                    <defs>
                      <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="date" hide />
                    <Tooltip contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.05)' }} />
                    <Area type="monotone" dataKey="totalPrice" stroke="#3b82f6" strokeWidth={4} fillOpacity={1} fill="url(#colorVal)" />
                  </AreaChart>
                </ResponsiveContainer>
             </div>
          </div>
        </div>

        {/* Right Col: Activity & Distribution */}
        <div className="lg:col-span-4 space-y-10">
           {/* Studio Activity Feed */}
           <div className="bg-white border border-slate-100 rounded-[3rem] p-10 shadow-sm">
              <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight mb-8">Live Feed</h3>
              <div className="space-y-6">
                 {recentActivity.map((act, i) => (
                   <div key={i} className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center shrink-0">
                         <act.icon className="w-5 h-5 text-slate-400" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-bold text-slate-900"><span className="text-slate-400">{act.name}</span> {act.action}</p>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">{act.time}</p>
                      </div>
                   </div>
                 ))}
              </div>
              <button className="w-full mt-8 py-4 border-2 border-dashed border-slate-100 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-400 hover:border-slate-300 hover:text-slate-900 transition-all">
                Refresh Protocol Log
              </button>
           </div>

           <div className="bg-white border border-slate-100 rounded-[3rem] p-10 shadow-sm relative overflow-hidden">
             <div className="absolute top-0 right-0 p-6">
                <PieChartIcon className="w-6 h-6 text-slate-100" />
             </div>
             <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight mb-8">Event Mix</h3>
             <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={typeData} dataKey="value" innerRadius={50} outerRadius={80} cornerRadius={10} paddingAngle={5}>
                      {typeData.map((_, i) => <ReCell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
             </div>
             <div className="space-y-3 mt-4">
                {typeData.map((d, i) => (
                  <div key={i} className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }}></div>
                      <span className="text-slate-500">{d.name}</span>
                    </div>
                    <span className="text-slate-900">{d.value}</span>
                  </div>
                ))}
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

// Helper components for icons missing in initial thoughts
const CheckCircle = (props: any) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
);
const PieChartIcon = (props: any) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>
);

export default Dashboard;


import React from 'react';
import { Clock, IndianRupee, Ban, Cigarette, UtensilsCrossed, Footprints, Info, Sparkles, Star, Film, CreditCard, Cake, Users, Trophy, ShieldCheck, Heart } from 'lucide-react';

const AboutCineParty: React.FC = () => {
  const rules = [
    { icon: Cigarette, label: 'No Smoking', detail: 'Maintaining a fresh atmosphere for every premiere.', color: 'text-rose-600', bg: 'bg-rose-50', border: 'border-rose-100' },
    { icon: UtensilsCrossed, label: 'No Outside Food', detail: 'External catering is strictly prohibited inside the hall.', color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100' },
    { icon: Footprints, label: 'Shoes Protocol', detail: 'Shoes must be removed at the entrance carpet.', color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-100' },
  ];

  const comparison = [
    { feature: 'Hall Privacy', public: 'Shared with strangers', cineparty: '100% Private Studio' },
    { feature: 'Special Entry', public: 'None (Walk-in)', cineparty: 'Fog, Bubbles & Rose Entry' },
    { feature: 'Personalization', public: 'Standard Movie', cineparty: 'Your Video, Photos, & Music' },
    { feature: 'Food/Cake', public: 'Popcorn Only', cineparty: 'Custom Cake Cutting Setup' },
  ];

  return (
    <div className="space-y-16 animate-slideUp pb-24">
      {/* Hero Section - Boutique Style */}
      <div className="relative overflow-hidden bg-white border border-slate-100 rounded-[4rem] p-12 lg:p-20 shadow-2xl">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-slate-50 to-transparent pointer-events-none"></div>
        <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-blue-500/5 blur-[120px] rounded-full"></div>
        
        <div className="relative z-10 flex flex-col lg:flex-row items-center gap-16">
          <div className="flex-1 space-y-10">
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-slate-900 text-white text-[11px] font-black uppercase tracking-[0.4em]">
              <Trophy className="w-4 h-4 text-amber-400" /> #1 Event Studio in Rajkot
            </div>
            <h1 className="text-6xl lg:text-9xl font-black text-slate-900 leading-[0.8] tracking-tighter uppercase">
              Beyond the <span className="text-transparent bg-clip-text bg-gradient-to-br from-amber-400 to-amber-600 font-cinema italic">Big Screen</span>
            </h1>
            <p className="text-slate-500 text-xl font-medium leading-relaxed max-w-2xl">
              CineParty isn't just a theater—it's your private stage. We combine cinematic technology with personalized celebrations to create memories that last forever.
            </p>
          </div>
          <div className="shrink-0 relative">
             <div className="w-80 h-80 rounded-[4rem] bg-slate-900 flex items-center justify-center relative z-10 shadow-2xl overflow-hidden group">
                <div className="absolute inset-0 gold-shimmer opacity-10 group-hover:opacity-20 transition-opacity"></div>
                <div className="text-center relative z-10 p-10">
                   <p className="text-amber-500 text-[10px] font-black uppercase tracking-[0.3em] mb-4">Starting From</p>
                   <div className="flex items-baseline justify-center gap-1">
                      <span className="text-3xl font-black text-white font-cinema">₹</span>
                      <span className="text-8xl font-black text-white tracking-tighter">2000</span>
                   </div>
                   <p className="text-slate-400 text-[10px] font-black uppercase mt-4 tracking-widest">Premium 2-Hour Act</p>
                </div>
             </div>
             <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-xl border border-slate-100 z-20 animate-bounce">
                <Star className="text-amber-500 w-10 h-10 fill-amber-500" />
             </div>
          </div>
        </div>
      </div>

      {/* Comparison: Why CineParty? - This attracts customers */}
      <div className="bg-slate-50 rounded-[4rem] p-12 lg:p-20 border border-slate-200">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-black text-slate-900 uppercase tracking-tight">The Upgrade You Deserve</h2>
          <p className="text-slate-500 font-bold uppercase text-xs tracking-widest mt-3">CineParty vs Ordinary Theaters</p>
        </div>
        <div className="max-w-4xl mx-auto space-y-4">
          {comparison.map((item, i) => (
            <div key={i} className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center p-8 bg-white rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-md transition-all">
              <div className="text-slate-900 font-black uppercase text-sm tracking-tight">{item.feature}</div>
              <div className="text-slate-400 text-sm font-medium italic">{item.public}</div>
              <div className="flex items-center gap-3 text-slate-900 font-extrabold uppercase text-sm tracking-widest">
                <div className="w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center"><ShieldCheck className="w-4 h-4 text-emerald-600" /></div>
                {item.cineparty}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Policy Section */}
        <div className="bg-white border border-slate-100 rounded-[3rem] p-12 shadow-xl">
          <h3 className="text-3xl font-black text-slate-900 uppercase tracking-tight mb-12 flex items-center gap-4">
            <Info className="text-amber-500 w-8 h-8" /> Studio Specs
          </h3>
          <div className="space-y-10">
            {[
              { label: '₹1,000 Advance', detail: 'Confirmation requires immediate ledger update. Non-refundable for no-shows.', icon: CreditCard, color: 'text-emerald-600', bg: 'bg-emerald-50' },
              { label: '2 Hour Baseline', detail: 'Our sessions are curated for a perfect 120-minute immersive experience.', icon: Clock, color: 'text-blue-600', bg: 'bg-blue-50' },
              { label: '25 Guest Cap', detail: 'Intimate setting. We do not exceed our 25-audience limit for safety.', icon: Users, color: 'text-pink-600', bg: 'bg-pink-50' },
            ].map((item, idx) => (
              <div key={idx} className="flex items-start gap-8 group">
                <div className={`w-20 h-20 ${item.bg} rounded-[2rem] flex items-center justify-center shrink-0 border border-transparent group-hover:border-slate-200 transition-all shadow-sm`}>
                  <item.icon className={`${item.color} w-8 h-8`} />
                </div>
                <div>
                  <p className={`font-black text-2xl tracking-tighter uppercase ${item.color}`}>{item.label}</p>
                  <p className="text-slate-500 text-sm font-bold mt-2 leading-relaxed">{item.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Rules Section */}
        <div className="bg-white border border-slate-100 rounded-[3rem] p-12 shadow-xl relative overflow-hidden">
           <div className="absolute -bottom-10 -right-10 opacity-5">
              <ShieldCheck className="w-64 h-64" />
           </div>
          <h3 className="text-3xl font-black text-slate-900 uppercase tracking-tight mb-12 flex items-center gap-4">
            <Ban className="text-rose-600 w-8 h-8" /> House Protocols
          </h3>
          <div className="grid grid-cols-1 gap-6">
            {rules.map((rule, idx) => (
              <div key={idx} className={`group flex items-center gap-8 p-8 ${rule.bg} border-2 ${rule.border} rounded-[2.5rem] hover:shadow-lg transition-all`}>
                <div className={`w-16 h-16 bg-white rounded-2xl flex items-center justify-center shrink-0 border ${rule.border} group-hover:scale-110 transition-transform`}>
                  <rule.icon className={`${rule.color} w-8 h-8`} />
                </div>
                <div>
                  <p className="text-slate-900 font-black text-xl uppercase tracking-tight">{rule.label}</p>
                  <p className="text-slate-500 text-xs font-bold mt-1 tracking-wide">{rule.detail}</p>
                </div>
              </div>
            ))}
            
            <div className="mt-8 flex items-center gap-8 p-10 bg-slate-900 rounded-[2.5rem] shadow-2xl relative group overflow-hidden">
               <div className="absolute inset-0 gold-shimmer opacity-0 group-hover:opacity-10 transition-opacity"></div>
               <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center shrink-0">
                  <Heart className="text-pink-400 w-8 h-8 fill-pink-400" />
               </div>
               <div className="relative z-10">
                  <p className="text-white font-black text-2xl uppercase tracking-tight">Cake & Catering</p>
                  <p className="text-slate-400 text-[11px] font-black uppercase tracking-[0.2em] mt-2">Personalized setup available on request.</p>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutCineParty;

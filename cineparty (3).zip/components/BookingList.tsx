
import React, { useState } from 'react';
import { Booking, BookingStatus, EventType } from '../types';
import { Search, Calendar as CalIcon, Edit3, Trash, Sparkles, Clock, Users, Film, Star } from 'lucide-react';

interface BookingListProps {
  bookings: Booking[];
  onDelete: (id: string) => void;
  onUpdateStatus: (id: string, status: BookingStatus) => void;
}

const BookingList: React.FC<BookingListProps> = ({ bookings, onDelete, onUpdateStatus }) => {
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<string>('All');

  const filtered = bookings.filter(b => {
    const matchesSearch = b.clientName.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filterType === 'All' || b.type === filterType;
    return matchesSearch && matchesFilter;
  });

  const getStatusStyle = (status: BookingStatus) => {
    switch (status) {
      case BookingStatus.CONFIRMED: return 'bg-emerald-50 text-emerald-600 border-emerald-100';
      case BookingStatus.PENDING: return 'bg-amber-50 text-amber-600 border-amber-100';
      case BookingStatus.COMPLETED: return 'bg-blue-50 text-blue-600 border-blue-100';
      case BookingStatus.CANCELLED: return 'bg-rose-50 text-rose-600 border-rose-100';
      default: return 'bg-slate-50 text-slate-500 border-slate-100';
    }
  };

  return (
    <div className="space-y-10 animate-fadeIn pb-24">
      <div className="flex flex-col xl:flex-row gap-6 items-center justify-between">
        <div className="relative w-full xl:w-[500px] group">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-slate-900 transition-colors w-5 h-5" />
          <input
            type="text"
            placeholder="Search premiere archives..."
            className="w-full bg-white border-2 border-slate-100 rounded-[2rem] pl-16 pr-8 py-5 text-slate-900 focus:outline-none focus:border-slate-900 transition-all font-bold tracking-tight shadow-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-2 w-full xl:w-auto overflow-x-auto pb-4 no-scrollbar">
          {['All', ...Object.values(EventType)].map(type => (
            <button 
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all duration-300 ${
                filterType === type 
                  ? 'bg-slate-900 text-white shadow-xl scale-105' 
                  : 'bg-white border-2 border-slate-100 text-slate-400 hover:border-slate-300 hover:text-slate-900'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8">
        {filtered.length === 0 ? (
          <div className="bg-white border-4 border-dashed border-slate-100 rounded-[4rem] py-40 text-center flex flex-col items-center gap-6">
            <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center">
               <Film className="w-10 h-10 text-slate-200" />
            </div>
            <div className="space-y-2">
              <h4 className="text-3xl font-black text-slate-300 uppercase tracking-tighter">No Premiere Matches</h4>
              <p className="text-slate-200 font-bold text-xs uppercase tracking-widest">Adjust your search parameters</p>
            </div>
          </div>
        ) : (
          filtered.map(booking => (
            <div key={booking.id} className="group relative bg-white border-2 border-slate-100 rounded-[3rem] p-10 hover:border-slate-300 transition-all duration-500 flex flex-col lg:flex-row gap-10 shadow-sm hover:shadow-2xl overflow-hidden">
              
              {/* Ticket Accent Strip */}
              <div className="hidden lg:block absolute left-[120px] top-0 bottom-0 w-[2px] border-l-2 border-dashed border-slate-100"></div>
              
              <div className="flex-1 flex flex-col md:flex-row gap-10">
                <div className="w-24 h-24 bg-slate-50 rounded-[2.5rem] flex items-center justify-center shrink-0 border border-slate-100 shadow-inner group-hover:scale-110 transition-transform">
                   <Film className="w-8 h-8 text-slate-900" />
                </div>
                
                <div className="flex-1 space-y-6">
                  <div className="flex flex-wrap items-center gap-6">
                    <h3 className="text-4xl font-black text-slate-900 tracking-tighter leading-none">{booking.clientName}</h3>
                    <div className={`px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] border shadow-sm ${getStatusStyle(booking.status)}`}>
                      {booking.status}
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-x-12 gap-y-5">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600 border border-blue-100">
                        <CalIcon className="w-6 h-6" />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Date</span>
                        <span className="text-lg text-slate-900 font-black">{new Date(booking.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-pink-50 flex items-center justify-center text-pink-600 border border-pink-100">
                        <Clock className="w-6 h-6" />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Call Time</span>
                        <span className="text-lg text-slate-900 font-black">{booking.startTime}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-600 border border-emerald-100">
                        <Users className="w-6 h-6" />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Audience</span>
                        <span className="text-lg text-slate-900 font-black">{booking.guestCount}/25 Seats</span>
                      </div>
                    </div>
                  </div>

                  {booking.extras && booking.extras.length > 0 && (
                    <div className="flex flex-wrap gap-3 pt-6 border-t border-slate-50">
                      {booking.extras.map(extra => (
                        <div key={extra} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-50 border border-slate-100 text-[10px] text-slate-600 font-black uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-colors cursor-default">
                          <Sparkles className="w-3 h-3 text-amber-500" />
                          <span>{extra}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex lg:flex-col items-center lg:items-end justify-between lg:justify-center gap-10 border-t lg:border-t-0 lg:border-l border-slate-100 pt-10 lg:pt-0 lg:pl-12 min-w-[240px]">
                <div className="text-right">
                  <p className="text-[10px] text-slate-400 uppercase font-black tracking-[0.3em] mb-2">Premiere Ledger</p>
                  <div className="flex items-baseline gap-1 justify-end">
                    <span className="text-2xl font-black text-slate-300 font-cinema">₹</span>
                    <span className="text-6xl font-black text-slate-900 tracking-tighter leading-none">{booking.totalPrice.toLocaleString()}</span>
                  </div>
                </div>
                <div className="flex gap-4">
                  <button 
                    onClick={() => onUpdateStatus(booking.id, BookingStatus.CONFIRMED)}
                    className="w-16 h-16 flex items-center justify-center bg-white hover:bg-slate-900 text-slate-400 hover:text-white rounded-[1.5rem] border border-slate-100 hover:border-slate-900 transition-all shadow-sm"
                  >
                    <Edit3 className="w-7 h-7" />
                  </button>
                  <button 
                    onClick={() => onDelete(booking.id)}
                    className="w-16 h-16 flex items-center justify-center bg-white hover:bg-red-500 text-slate-400 hover:text-white rounded-[1.5rem] border border-slate-100 hover:border-red-500 transition-all shadow-sm"
                  >
                    <Trash className="w-7 h-7" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default BookingList;

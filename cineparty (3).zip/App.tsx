
import React, { useState, useEffect } from 'react';
import { Booking, BookingStatus, EventType } from './types';
import Dashboard from './components/Dashboard';
import BookingList from './components/BookingList';
import SmartBookingForm from './components/SmartBookingForm';
import AboutCineParty from './components/AboutCineParty';
import { LayoutDashboard, ListPlus, Calendar, Info, Film, ShieldCheck, BellRing, Share2 } from 'lucide-react';

const MOCK_DATA: Booking[] = [
  {
    id: '1',
    clientName: 'Rahul Sharma',
    date: new Date().toISOString().split('T')[0], // Today
    startTime: '19:00',
    type: EventType.ANNIVERSARY,
    status: BookingStatus.CONFIRMED,
    notes: 'Surprise entry with Fog',
    guestCount: 12,
    totalPrice: 2000,
    extras: ['Fog Entry']
  },
  {
    id: '2',
    clientName: 'Priya Patel',
    date: '2025-05-20',
    startTime: '15:00',
    type: EventType.KIDS_PARTY,
    status: BookingStatus.PENDING,
    notes: 'Spider-man screening',
    guestCount: 20,
    totalPrice: 2000,
    extras: ['Bubble Entry']
  }
];

const App: React.FC = () => {
  const [bookings, setBookings] = useState<Booking[]>(() => {
    const saved = localStorage.getItem('cineparty_bookings');
    return saved ? JSON.parse(saved) : MOCK_DATA;
  });
  const [activeTab, setActiveTab] = useState<'dashboard' | 'list' | 'add' | 'details'>('dashboard');

  useEffect(() => {
    localStorage.setItem('cineparty_bookings', JSON.stringify(bookings));
  }, [bookings]);

  const addBooking = (newBooking: Booking) => {
    setBookings([newBooking, ...bookings]);
    setActiveTab('list');
  };

  const deleteBooking = (id: string) => {
    setBookings(bookings.filter(b => b.id !== id));
  };

  const updateStatus = (id: string, status: BookingStatus) => {
    setBookings(bookings.map(b => b.id === id ? { ...b, status } : b));
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'CineParty Manager',
          text: 'Manage your CineParty events seamlessly with our smart dashboard!',
          url: window.location.href,
        });
      } catch (err) {
        console.error('Error sharing:', err);
      }
    } else {
      // Fallback: Copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      alert('App link copied to clipboard!');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row overflow-hidden text-slate-900">
      {/* Sidebar - Clean Light Theme */}
      <nav className="w-full md:w-64 bg-white border-r border-slate-200 p-6 flex flex-col shrink-0 shadow-sm z-20">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-pink-500/20">
            <Film className="text-white w-6 h-6" />
          </div>
          <h1 className="text-2xl font-cinema tracking-widest text-slate-900">CINEPARTY</h1>
        </div>

        <div className="space-y-2 flex-1">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'add', label: 'New Booking', icon: ListPlus },
            { id: 'list', label: 'Schedule', icon: Calendar },
            { id: 'details', label: 'Protocols', icon: ShieldCheck },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${
                activeTab === item.id 
                ? 'bg-slate-900 text-white shadow-md' 
                : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
          
          <button
            onClick={handleShare}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-slate-500 hover:bg-pink-50 hover:text-pink-600 transition-all mt-4 border border-dashed border-slate-200"
          >
            <Share2 className="w-5 h-5" />
            Share App
          </button>
        </div>

        <div className="mt-auto pt-6 border-t border-slate-100">
          <div className="bg-slate-100 rounded-xl p-4">
            <div className="flex items-center gap-2 text-[10px] text-pink-600 font-black mb-2 uppercase tracking-widest">
              <BellRing className="w-3 h-3" /> PWA Status
            </div>
            <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
              Open in browser and select "Add to Home Screen" to install as a mobile app.
            </p>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 md:p-10 scroll-smooth">
        <div className="max-w-7xl mx-auto">
          <header className="mb-10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-4xl font-black text-slate-900 uppercase tracking-tight">
                {activeTab === 'dashboard' && 'Operations Hub'}
                {activeTab === 'add' && 'Create Premiere'}
                {activeTab === 'list' && 'Booking Roll'}
                {activeTab === 'details' && 'Venue Guide'}
              </h2>
              <p className="text-slate-500 font-bold text-sm mt-1">
                {activeTab === 'dashboard' && 'Overview of upcoming celebrations and revenue.'}
                {activeTab === 'add' && 'Register a new cinematic event.'}
                {activeTab === 'list' && 'Managing the lineup of private screenings.'}
                {activeTab === 'details' && 'House rules and pricing guidelines.'}
              </p>
            </div>
            <div className="hidden md:flex items-center gap-3 bg-white px-5 py-2.5 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Service Status</span>
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.3)]"></div>
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">Online</span>
            </div>
          </header>

          <div className="min-h-[70vh]">
            {activeTab === 'dashboard' && <Dashboard bookings={bookings} />}
            {activeTab === 'add' && <SmartBookingForm onAdd={addBooking} />}
            {activeTab === 'list' && (
              <BookingList 
                bookings={bookings} 
                onDelete={deleteBooking} 
                onUpdateStatus={updateStatus} 
              />
            )}
            {activeTab === 'details' && <AboutCineParty />}
          </div>
        </div>
      </main>

      {/* Footer Mobile Nav */}
      <div className="md:hidden sticky bottom-0 left-0 right-0 bg-white/90 backdrop-blur-md border-t border-slate-100 px-4 py-4 flex justify-around items-center z-50 shadow-lg">
        {[
          { id: 'dashboard', icon: LayoutDashboard },
          { id: 'add', icon: ListPlus },
          { id: 'list', icon: Calendar },
          { id: 'details', icon: ShieldCheck },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id as any)}
            className={`p-3 rounded-2xl transition-all ${
              activeTab === item.id 
              ? 'bg-slate-900 text-white shadow-lg scale-110' 
              : 'text-slate-400'
            }`}
          >
            <item.icon className="w-6 h-6" />
          </button>
        ))}
      </div>
    </div>
  );
};

export default App;
